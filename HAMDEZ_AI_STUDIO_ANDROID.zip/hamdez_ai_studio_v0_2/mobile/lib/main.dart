import 'package:flutter/material.dart';

void main() => runApp(const HamdezApp());

const gold = Color(0xFFD7B56D);
const ink = Color(0xFF10111A);
const panel = Color(0xFF1B1D29);

class HamdezApp extends StatelessWidget {
  const HamdezApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HAMDEZ AI STUDIO',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: ink,
        colorScheme: ColorScheme.fromSeed(
          seedColor: gold,
          brightness: Brightness.dark,
          surface: panel,
        ),
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: panel,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class ToolItem {
  final String title;
  final String subtitle;
  final IconData icon;
  final String hint;
  const ToolItem(this.title, this.subtitle, this.icon, this.hint);
}

const tools = [
  ToolItem('Musique IA', 'Chansons, paroles et instrumentales', Icons.music_note,
      'Décris le thème, le style musical, la langue et l’ambiance de ta chanson.'),
  ToolItem('Vidéo IA', 'Clips, Reels et vidéos courtes', Icons.movie_creation,
      'Décris la scène, les personnages, le format et la durée souhaitée.'),
  ToolItem('Images IA', 'Affiches, pochettes et visuels', Icons.image,
      'Décris précisément l’image que tu souhaites créer.'),
  ToolItem('Voix IA', 'Voix off et narration', Icons.record_voice_over,
      'Colle ton texte et précise le type de voix et la langue.'),
  ToolItem('Textes IA', 'Scripts, idées et publications', Icons.edit_note,
      'Explique le sujet, le public et le ton du texte à rédiger.'),
];

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  final List<String> history = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(
          index: tab,
          children: [
            _home(),
            _history(),
            _profile(),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: panel,
        indicatorColor: gold.withOpacity(.18),
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'Créer'),
          NavigationDestination(icon: Icon(Icons.folder_open), label: 'Projets'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Compte'),
        ],
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
    children: [
      Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: gold.withOpacity(.14),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: gold.withOpacity(.5)),
            ),
            child: const Icon(Icons.graphic_eq, color: gold, size: 29),
          ),
          const SizedBox(width: 12),
          const Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('HAMDEZ AI STUDIO',
                style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
              SizedBox(height: 3),
              Text('La créativité sans frontières',
                style: TextStyle(color: Colors.white60, fontSize: 12)),
            ],
          )),
          IconButton(
            onPressed: () => _showInfo(),
            icon: const Icon(Icons.info_outline),
          )
        ],
      ),
      const SizedBox(height: 26),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(
            colors: [Color(0xFF343044), Color(0xFF191A26)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          border: Border.all(color: gold.withOpacity(.28)),
        ),
        child: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('DONNE VIE À TES IDÉES',
              style: TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 1)),
            SizedBox(height: 10),
            Text('Crée de la musique, des vidéos, des images et des textes avec l’IA.',
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, height: 1.25)),
            SizedBox(height: 10),
            Text('Un seul studio. Toutes tes créations.',
              style: TextStyle(color: Colors.white70)),
          ],
        ),
      ),
      const SizedBox(height: 26),
      const Text('QUE VEUX-TU CRÉER ?',
        style: TextStyle(fontSize: 12, letterSpacing: 1.2,
          color: gold, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      ...tools.map((tool) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Material(
          color: panel,
          borderRadius: BorderRadius.circular(17),
          child: InkWell(
            borderRadius: BorderRadius.circular(17),
            onTap: () => _openCreator(tool),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    width: 48, height: 48,
                    decoration: BoxDecoration(
                      color: gold.withOpacity(.12),
                      borderRadius: BorderRadius.circular(14)),
                    child: Icon(tool.icon, color: gold, size: 25),
                  ),
                  const SizedBox(width: 14),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tool.title, style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 4),
                      Text(tool.subtitle, style: const TextStyle(
                        color: Colors.white60, fontSize: 12)),
                    ],
                  )),
                  const Icon(Icons.chevron_right, color: Colors.white54),
                ],
              ),
            ),
          ),
        ),
      )),
      const SizedBox(height: 12),
      const Text('Prototype de l’interface — les moteurs IA seront connectés à l’étape suivante.',
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.white38, fontSize: 11)),
    ],
  );

  void _openCreator(ToolItem tool) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => CreatorScreen(
        tool: tool,
        onCreated: (prompt) => setState(() {
          history.insert(0, '${tool.title} — $prompt');
        }),
      ),
    ));
  }

  Widget _history() => Padding(
    padding: const EdgeInsets.all(20),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('MES PROJETS', style: TextStyle(
        fontSize: 22, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      const Text('Tes demandes apparaîtront ici.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 18),
      Expanded(child: history.isEmpty
        ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.folder_open, size: 48, color: Colors.white30),
            SizedBox(height: 10),
            Text('Aucun projet pour le moment', style: TextStyle(color: Colors.white54)),
          ]))
        : ListView(children: history.map((e) => Card(
            color: panel, child: ListTile(
              leading: const Icon(Icons.auto_awesome, color: gold),
              title: Text(e, maxLines: 2, overflow: TextOverflow.ellipsis),
            ),
          )).toList()),
      ),
    ]),
  );

  Widget _profile() => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('MON COMPTE', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
    const SizedBox(height: 18),
    const CircleAvatar(radius: 36, backgroundColor: panel,
      child: Icon(Icons.person, size: 38, color: gold)),
    const SizedBox(height: 12),
    const Center(child: Text('Bienvenue dans HAMDEZ AI STUDIO',
      style: TextStyle(fontWeight: FontWeight.bold))),
    const SizedBox(height: 22),
    _profileTile(Icons.language, 'Langue', 'Français (prototype)'),
    _profileTile(Icons.workspace_premium, 'Offre', 'Gratuite — crédits à définir'),
    _profileTile(Icons.security, 'Confidentialité', 'À configurer avant lancement'),
    _profileTile(Icons.help_outline, 'Assistance', 'À configurer'),
    const SizedBox(height: 18),
    const Text('Les comptes, paiements et abonnements seront activés après la connexion du backend.',
      style: TextStyle(color: Colors.white38, fontSize: 12)),
  ]);

  Widget _profileTile(IconData icon, String title, String value) => Card(
    color: panel, child: ListTile(
      leading: Icon(icon, color: gold),
      title: Text(title),
      subtitle: Text(value, style: const TextStyle(color: Colors.white54)),
    ),
  );

  void _showInfo() => showDialog(
    context: context,
    builder: (_) => AlertDialog(
      backgroundColor: panel,
      title: const Text('À propos'),
      content: const Text('HAMDEZ AI STUDIO est en cours de développement. Cette version présente l’interface de départ.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context),
        child: const Text('Fermer'))],
    ),
  );
}

class CreatorScreen extends StatefulWidget {
  final ToolItem tool;
  final ValueChanged<String> onCreated;
  const CreatorScreen({super.key, required this.tool, required this.onCreated});

  @override
  State<CreatorScreen> createState() => _CreatorScreenState();
}

class _CreatorScreenState extends State<CreatorScreen> {
  final controller = TextEditingController();
  String language = 'Français';
  String style = 'Au choix';
  bool submitted = false;

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.tool.title)),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Icon(widget.tool.icon, color: gold, size: 48),
      const SizedBox(height: 12),
      Text('Créer avec ${widget.tool.title}',
        style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      Text(widget.tool.hint, style: const TextStyle(color: Colors.white60)),
      const SizedBox(height: 22),
      const Text('TA DESCRIPTION', style: TextStyle(
        color: gold, fontWeight: FontWeight.bold, fontSize: 12)),
      const SizedBox(height: 8),
      TextField(
        controller: controller,
        minLines: 5, maxLines: 8,
        decoration: const InputDecoration(
          hintText: 'Écris ici ce que tu souhaites créer...',
          alignLabelWithHint: true,
        ),
      ),
      const SizedBox(height: 18),
      const Text('LANGUE', style: TextStyle(
        color: gold, fontWeight: FontWeight.bold, fontSize: 12)),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(
        value: language,
        items: ['Français', 'English', 'Español', 'Português', 'العربية']
          .map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
        onChanged: (v) => setState(() => language = v ?? language),
      ),
      const SizedBox(height: 18),
      const Text('STYLE / AMBIANCE', style: TextStyle(
        color: gold, fontWeight: FontWeight.bold, fontSize: 12)),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(
        value: style,
        items: ['Au choix', 'Moderne', 'Afro', 'Pop', 'Cinématique', 'Professionnel']
          .map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
        onChanged: (v) => setState(() => style = v ?? style),
      ),
      const SizedBox(height: 24),
      FilledButton.icon(
        style: FilledButton.styleFrom(
          backgroundColor: gold, foregroundColor: ink,
          padding: const EdgeInsets.symmetric(vertical: 16)),
        onPressed: submitted ? null : () {
          if (controller.text.trim().isEmpty) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Écris d’abord une description.')));
            return;
          }
          widget.onCreated(controller.text.trim());
          setState(() => submitted = true);
          showDialog(context: context, builder: (_) => AlertDialog(
            backgroundColor: panel,
            title: const Text('Demande enregistrée dans le prototype'),
            content: const Text('L’interface fonctionne. La génération réelle sera activée lorsque les API IA et le serveur sécurisé seront connectés.'),
            actions: [TextButton(
              onPressed: () { Navigator.pop(context); Navigator.pop(context); },
              child: const Text('Compris'))],
          ));
        },
        icon: const Icon(Icons.auto_awesome),
        label: const Text('GÉNÉRER AVEC L’IA'),
      ),
      const SizedBox(height: 12),
      const Text('La génération réelle nécessite une connexion aux services IA. Aucun résultat audio ou vidéo n’est encore produit dans cette version.',
        style: TextStyle(color: Colors.white38, fontSize: 11)),
    ]),
  );
}
