# HAMDEZ AI STUDIO — v0.2 foundation

This is a development foundation for an Android-first, international AI creation app.

## Included
- Flutter Android UI (music, video, images, voice, text, projects, account).
- Node/Express backend skeleton.
- API endpoints: health, catalog, user demo profile, create job, job status.
- Basic request validation, rate limiting, security headers and monthly budget guard.
- Provisional credit estimates for each tool.

## Important limitations
This is NOT a production-ready application and it does NOT yet generate real music, video, images or speech.
The backend uses an in-memory demo user ledger and a demo header (`x-demo-user`). Do not expose it publicly.
Before launch, replace demo auth and storage with Firebase Auth or another secure identity provider,
a transactional database, private object storage, verified provider adapters, webhook/job processing,
moderation, billing, refund handling, and monitoring.

## Run the backend locally
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```
Then open `http://localhost:8080/health`.

Example request:
```bash
curl -X POST http://localhost:8080/v1/jobs \
  -H 'Content-Type: application/json' \
  -H 'x-demo-user: local-test-user' \
  -d '{"type":"text","prompt":"Écris une légende motivante sur la persévérance."}'
```

## Run Android app
Install Flutter + Android Studio, then:
```bash
cd mobile
flutter pub get
flutter run
```

## Credit policy draft
Initial credits are placeholders, not final prices:
- Text: 1
- Image: 5
- Voice: 5
- Music: 30
- Video: 60

Set final credit costs only after measuring each provider's real price, failed-job rates,
storage/bandwidth and payment fees. A user should see the credit cost before confirming.
Never debit credits for failed generations.


## Build APK without owning a computer (Android phone workflow)
This project includes a GitHub Actions workflow at `.github/workflows/build-android.yml`.
1. On your Android phone, create/sign in to a GitHub account in Chrome.
2. Create a new **private** repository.
3. Upload the contents of this ZIP into the repository, keeping the `.github/workflows/build-android.yml` path.
4. Open the repository's **Actions** tab and run **Build Android APK** (or push to `main`).
5. When the workflow completes, open the run, scroll to **Artifacts**, and download `hamdez-ai-studio-android-apk`.
6. Extract the artifact ZIP on your phone and install the APK. Android may ask you to allow installation from that browser/files app.

The cloud workflow compiles the current prototype; it does not connect real AI generation. Keep the repository private and never commit API keys, passwords, signing keys, or payment secrets.
