import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import "dotenv/config";

const app = express();
app.use(helmet());
app.use(cors({ origin: (process.env.ALLOWED_ORIGINS || "").split(",").filter(Boolean) }));
app.use(express.json({ limit: "1mb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 30 }));

const PORT = Number(process.env.PORT || 8080);
const MONTHLY_BUDGET_XOF = Number(process.env.MONTHLY_BUDGET_XOF || 10000);

// Demo-only in-memory ledger. Replace with transactional database before public launch.
const users = new Map();
const jobs = new Map();
let monthlySpendXof = 0;

const catalog = {
  music: { credits: 30, status: "provider_not_connected" },
  video: { credits: 60, status: "provider_not_connected" },
  image: { credits: 5, status: "provider_not_connected" },
  voice: { credits: 5, status: "provider_not_connected" },
  text: { credits: 1, status: "provider_not_connected" }
};

app.get("/health", (_req, res) => res.json({ ok: true, service: "hamdez-ai-studio-api" }));
app.get("/v1/catalog", (_req, res) => res.json({
  currency: "XOF",
  budgetMonthlyXof: MONTHLY_BUDGET_XOF,
  tools: catalog,
  note: "Credits are provisional until provider prices and real generation costs are verified."
}));

// Placeholder identity for local development only. Replace with Firebase Auth/JWT verification.
function demoUser(req, res, next) {
  const userId = req.header("x-demo-user");
  if (!userId) return res.status(401).json({ error: "Authentication required." });
  req.userId = userId;
  if (!users.has(userId)) users.set(userId, { credits: 100, spentCredits: 0 });
  next();
}

app.get("/v1/me", demoUser, (req, res) => res.json(users.get(req.userId)));

app.post("/v1/jobs", demoUser, (req, res) => {
  const { type, prompt, language = "English", style = "default" } = req.body || {};
  if (!Object.hasOwn(catalog, type)) return res.status(400).json({ error: "Unknown creation type." });
  if (typeof prompt !== "string" || prompt.trim().length < 5 || prompt.length > 4000) {
    return res.status(400).json({ error: "Prompt must contain 5 to 4000 characters." });
  }

  const user = users.get(req.userId);
  const cost = catalog[type].credits;

  if (monthlySpendXof >= MONTHLY_BUDGET_XOF) {
    return res.status(429).json({ error: "Monthly generation budget reached. Try again next month." });
  }
  if (user.credits < cost) return res.status(402).json({ error: "Not enough credits." });

  // Important: no provider call and no credit debit until provider is connected.
  const id = crypto.randomUUID();
  const job = {
    id, userId: req.userId, type, prompt: prompt.trim(), language, style,
    status: "queued_provider_setup",
    creditEstimate: cost,
    createdAt: new Date().toISOString(),
    resultUrl: null
  };
  jobs.set(id, job);
  return res.status(202).json({
    job,
    message: "Request received by the prototype. Connect a provider adapter to generate real media."
  });
});

app.get("/v1/jobs/:id", demoUser, (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job || job.userId !== req.userId) return res.status(404).json({ error: "Job not found." });
  res.json(job);
});

app.listen(PORT, () => console.log(`HAMDEZ AI STUDIO API listening on ${PORT}`));
